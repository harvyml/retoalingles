<?php
# Include the Autoloader (see "Libraries" for install instructions)
require 'sendgrid-php/vendor/autoload.php';
use Mailgun\Mailgun;

# Instantiate the client.
$mgClient = new Mailgun('key-02dfe501b03a4985b945ba133d23f24f');
$domain = "sandbox404b7be33e5641fcb67fe1d7e0b4a569.mailgun.org";

# Make the call to the client.
$result = $mgClient->sendMessage("$domain",
          array('from'    => 'Mailgun Sandbox <postmaster@sandbox404b7be33e5641fcb67fe1d7e0b4a569.mailgun.org>',
                'to'      => 'Harvy <bewdevs@gmail.com>',
                'subject' => 'Hello Harvy',
                'text'    => 'Congratulations Harvy, you just sent an email with Mailgun!  You are truly awesome! '));

# You can see a record of this email in your logs: https://mailgun.com/app/logs .

# You can send up to 300 emails/day from this sandbox server.
# Next, you should add your own domain so you can send 10,000 emails/month for free.

if($result){
	echo "alright";
}
?>