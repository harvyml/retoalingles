const functions = require('firebase-functions')
const sg = require('sendgrid')("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");
var request = sg.emptyRequest({
  method: 'POST',
  path: '/v3/mail/send',
  body: {
    personalizations: [
      {
        to: [
          {
            email: 'bewdevs@gmail.com'
          }
        ],
        subject: 'Sending with SendGrid is Fun'
      }
    ],
    from: {
      email: 'harvyestebanml@gmail.com'
    },
    content: [
      {
        type: 'text/plain',
        value: 'and easy to do anywhere, even with Node.js'
      }
    ]
  }
});
 
// With promise 
sg.API(request)
  .then(function (response) {
    console.log(response.statusCode);
    console.log(response.body);
    console.log(response.headers);
  })
  .catch(function (error) {
    // error is an instance of SendGridError 
    // The full response is attached to error.response 
    console.log(error.response.statusCode);
  });
 
// With callback 
sg.API(request, function (error, response) {
  if (error) {
    console.log('Error response received');
  }else{
    console.log("all right")
  }
});







// SECOND METHOD
// using SendGrid's Node.js Library
// https://github.com/sendgrid/sendgrid-nodejs
/*

var sendgrid = require("sendgrid")("AIzaSyCtQevnFVECgj9gIDQPLQwNwu3s0n2BayE");
var email = new sendgrid.Email();

/* funcion de prueba para obtener emails desde firebase
email.addTo(function(){
  const emails = []
  var ref = firebase.database().ref().child("users").orderByChild("email")
  ref.on('value', snap => {
    snap.forEach(childSnap => {
      const emailNames = childSnap.val().email
      emails.push(emailNames)
    })
    return emails
  })
});


email.addTo("bewdevs@gmail.com")
email.setFrom("harvyestebanml@gmail.com");
email.setSubject("Sending with SendGrid is Fun");
email.setHtml("and easy to do anywhere, even with Node.js");

sendgrid.send(email);
*/