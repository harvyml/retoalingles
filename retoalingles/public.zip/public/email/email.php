<?php


require_once ('sendgrid-php/vendor/autoload.php');

/* Post Data */

$name = $_POST["nombre"];
$email = $_POST["email"];
$telefono = $_POST["telefono"];
$message = $_POST["mensaje"];

/* contents */

$from = new SendGrid\Email("Peticiones", "harvyestebanml@gmail.com");
$subject = "Nueva Peticion";
$to = new SendGrid\Email("Bew", "consultabew@gmail.com");

$content = new SendGrid\content("text/html", "

Email: {$email}<br>
Nombre: {$name}<br>
Mensaje: {$message}<br>
Telefono: {$telefono}

");

$mail = new SendGrid\Mail($from, $subject, $to, $content);

$apiKey = ("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");

$sg = new \SendGrid($apiKey);

/* Response */

$response = $sg->client->mail()->send()->post($mail);

if(!$response){
	echo "there´s something wrong";
}else{
	echo "Message sent";
	header("location: ../peticiones.html");
}

$name_txt = implode($name);
$message_txt = implode($message);

?>

<div id="name"><?php echo $name_txt; ?></div>
<div id="message"><?php echo $message_txt; ?></div>

<script>
	/* ----------------- Registro de primer form ---------------------------- */

function enviar(){
	var nom = $("#name").val()
	var mensaje = $("#message").val()
    //--------------------------------------------------------------------

  	var add = {
  		nombre: nom,
  		telefono: tel,
  		email: email,
  		mensaje: mensaje
  	}

    if(well){
      $('#form-datos').console.log(well)
    }

  	var promise = ref.push(add);

    window.location.href = "contacto.html";

};

setTimeout(function(){
	enviar()
}, 3000);

/*---------------------------------------------------------------------- */

</script>

