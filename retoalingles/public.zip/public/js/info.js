$(".show-questions i").on("click", function(){
	$(".questions .hidden").show(500);
	$(".show-questions").hide(300);
	$(".hide-questions:first").show(300);
})

$(".show-questions-2 i").on("click", function(){
	$(".questions .hidden-2").show(500);
	$(".show-questions-2").hide(300);
	$(".hide-questions:last").show(300);
})

// Esconder

$(".hide-questions:first").on("click", function(){
	$(".questions .hidden").hide(500);
	$(".show-questions").show(300);
	$(".hide-questions:first").hide(300);
})

$(".hide-questions:last").on("click", function(){
	$(".questions .hidden-2").hide(500);
	$(".show-questions-2").show(300);
	$(".hide-questions:last").hide(300);
})