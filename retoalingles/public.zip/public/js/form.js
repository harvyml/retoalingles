	 /*--------- connect to db --------*/


  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyCtQevnFVECgj9gIDQPLQwNwu3s0n2BayE",
    authDomain: "tecbew.firebaseapp.com",
    databaseURL: "https://tecbew.firebaseio.com",
    projectId: "tecbew",
    storageBucket: "tecbew.appspot.com",
    messagingSenderId: "541904235246"
  };
  firebase.initializeApp(config);

  // Notifications

const ref = firebase.database().ref().child('users');

/*ref.once("child_added", function(data){
  var message = data.val().mensaje;
  var nombre = data.val().nombre;

var stuff = {
  body: message,
  icon: "../logo/logo.png",
  timeout: 4000,
  onClick: function () {
        window.focus();
        this.close();
    }
}

Push.create(nombre, stuff);
})*/

  /*const messaging = firebase.messaging();
  messaging.requestPermission()
  .then(function(){
    console.log("have permission");
    return messaging.getToken();
  })
   .then(function(){
    console.log("have permission");
    return messaging.getToken();

  })

  .then(function(token){
    console.log(token);

  })

  .catch(function(){
    console.log("Error Ocurred.");
  })

  messaging.onMessage(function(payload){
    console.log("onMessage ", payload)
  })
*/

  /* ----------------- Registro de primer form ---------------------------- */

$("#btn-submit").on('click', function(well){

    //--------------------------------------------------------------------
    var nom = $("#input-email").val()
    var tel = $("#input-telefono").val()
    var email = $("#input-email").val()
    var mensaje = $("#mensaje").val()

    var add = {
      nombre: nom,
      telefono: tel,
      email: email,
      mensaje: mensaje
    }

    if(well){
      console.log("alright")
    }

    var promise = ref.push(add);

    window.location.href = "contacto.html";

     

});



/* ---------------------------------------------------------------------- */


/* ----------------- Registro de segundo form ---------------------------- */

$('#btn-consulta').on('click', function(well){

	var nom = $("#ip-nombre").val();
  	var email = $('#ip-email').val();
  	var mensaje = $("#mensaje-2").val();


  	var ref = firebase.database().ref().child('consultas');

  	var add = {
  		nombre: nom,
  		email: email,
  		mensaje: mensaje
  	}

  	ref.push(add);

  	if(well){
  		$("#form-sec").append("<p style='color: white; background: #fba919'>Tu consulta ha sido enviada, espera nuestra respuesta</P>")
  	}else{
  		$("#form-sec").append("<p style 'color: red'>Ha ocurrido un error</p>")
  	}

});

/*---------------------------------------------------------------------- */

// indicadores para telefono

$("#input-telefono").on("click", function(){
    $(".indi").show(300);
    hide();
});

function hide(){
    setInterval(function(){
       $(".indi").hide(300);
    }, 10000);
}
