/*
$(".places .colombia").on("hover", function(){
	$(".text-flag:first").show(500);
});

$(".places .peru").on("hover", function(){
	$(".text-flag:last").show(500);
})
*/
	
// Mostrar países 

/*s
$(".bew-where").on("mouseover", function(){
	$(".places").css({"display": "flex"})
});

$(".places").on("mouseover", function(){
	$(".places").css({"display": "flex"})
})

$(".places").on("mouseout", function(){
	$(".places").css({"display": "none"})
})*/