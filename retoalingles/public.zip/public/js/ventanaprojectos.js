function visibleWindow(){
	$('.cont-window').addClass('window-projectsvisible');
	$('.contenedor').addClass('contenedor-ani');
	
}

function removeWindow(){
	$('.cont-window').removeClass('window-projectsvisible');
	$('.contenedor').css({'background': 'none'},700);
    $('.contenedor').removeClass('contenedor-ani');
	
}

$('#close').on('click', function(){
	removeWindow()
})

function writteWindow(title, parrafo){
	$('.window-projects .window-projects-h2').text(title)
	$('.window-projects p').text(parrafo)	
}

$('#proyecto-1').on('click', function(){
	writteWindow('Responsive Design', 'Tu sitio Web Adaptable a dispositivos Moviles y a Cualquier Resolucion para una Mejor Comodidad Visual y Navegacion sencilla totalmente funcional');

	// No está permitido
	if($(window).outerWidth() < 400){
		console.log("No está permitido en moviles");
	}else{
		visibleWindow();
	}

})


$('#proyecto-2').on('click', function(){
	writteWindow('Página Informativa', 'Sitio Web, donde podras dar a conocer tu Startup y/o Empresa a mucha mas gente y ser mas Conocido, una Web Informativa tiene un unico Objetivo y es Informar, Llegar a mas Personas y una buena estrategia de Marketing para Empezar con tus Negocios');
	

	// No está permitido
	if($(window).outerWidth() < 400){
		console.log("No está permitido en moviles");
	}else{
		visibleWindow();
	}
})


$('#proyecto-3').on('click', function(){
	writteWindow('Portafolios Profesionales', 'Que mejor Empezar, con un Portafolio donde te das a Conocer, Tus Proyectos, Trabajos, y las Cosas que has hecho y aportado, tu Marca Personal empieza desde tu Propio Portafolio, La manera mas Facil de que te conozcan y Negocies');
	

	// No está permitido
	if($(window).outerWidth() < 400){
		console.log("No está permitido en moviles");
	}else{
		visibleWindow();
	}
})


$('#proyecto-4').on('click', function(){
	writteWindow('Startups y Empresas', 'Si tu Negocio no esta en internet, Tu negocio no Existe. Emprende y Haz crecer tu Empresa en Internet, comparte tus Productos, ofrece tus Servicios, Nosotros te Ayudamos a Crecer con un Sitio Web Funcional, Atractiva y Totalmente Personalizado, Confia en Nosotros, estamos Felices de Trabajar contigo');

	// No está permitido
	if($(window).outerWidth() < 400){
		console.log("No está permitido en moviles");
	}else{
		visibleWindow();
	}
})


$('#proyecto-5').on('click', function(){
	writteWindow('Blog Personal', 'Comparte tus anecdotas, tus pasatiempos, tus Intereses, Conversa con mas Personas, Publica Artículos Interesantes, y se una Gran Influencia para Mas Personas... Nosotros te Ayudamos, Tenlo por Seguro');

	// No está permitido
	if($(window).outerWidth() < 400){
		console.log("No está permitido en moviles");
	}else{
		visibleWindow();
	}
})


$('#proyecto-6').on('click', function(){
	writteWindow('Mantemiento de tus Sitios', '¿Tu sitio Web es muy Antiguo?, ¿Quieres Hacer un rediseño?, ¿Quieres añadir nuevas Caracteristicas?. Genial, nuestro Trabajo es Ayudarte y a Sobresalir con tu Sitio Web, Contactanos y Empezemos a mejorar Tu negocio en Internet');

	// No está permitido
	if($(window).outerWidth() < 400){
		console.log("No está permitido en moviles");
	}else{
		visibleWindow();
	}
})

