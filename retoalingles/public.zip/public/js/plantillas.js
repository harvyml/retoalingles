$(document).ready(function (){
	var altura = $(window).outerHeight(true);
	
	
	$('.main').css({
		height: altura + 'px'
	})
})