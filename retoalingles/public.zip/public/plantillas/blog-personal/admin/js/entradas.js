

$('#form-entradas').on("submit", function(e){				
		e.preventDefault();
    
var titulo = $('#titulo').val();
var texto = $('#texto').val();
var img = $('#img').val();

/*---------------------------------------*/
    
var frm = $('#form-entradas').serialize();
$.ajax({
	type: "POST",
	url: "php/entradas.php",
	data: frm
}).done(function(info){
    $('.con-form .row').html("<h2>Tu entrada se ve así</h2>" + "<div class='col s12 teal lighten-2'>" + "<h3>" + titulo + "</h3>" + "<p>" + texto + "</p>" + "<img src=' " + img + " '" + "</div>");
        

})
    
});
