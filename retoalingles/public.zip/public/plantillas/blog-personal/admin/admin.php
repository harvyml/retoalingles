<?php include 'php/session_start.php';?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="css/estilos.css">
	<link rel="stylesheet" href="../materialize/css/materialize.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.2/css/materialize.min.css">
	 <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<title>Crear Entradas</title>
</head>
<body>
<script src="../js/jquery.js"></script>
<script src="../materialize/js/materialize.min.js"></script>


	<div class="parallax-container">
    <div class="parallax"><img src="../img/parallax1.jpg"></div>
  </div>
  <div class="section white">
    <div class="row container">
      <h2 class="header">Crea tus entradas <?php echo $_SESSION["user"]; ?></h2>
      <p class="grey-text text-darken-3 lighten-3">Parallax is an effect where the background content or image in this case, is moved at a different speed than the foreground content while scrolling.</p>
    </div>
  </div>
	
	
		<div class="row">
			<div class="col s12">
				
			</div>
        
	    </div>
	    

        
        <div class="container con-form">
           
           <h2 class="title-h2">Ingresa aquí tus entradas</h2>
           
            <div class="row">
                <div class="col s12">
                    
                    <form action="" id="form-entradas" method="post">
                        <input type="text" name="titulo" class="input-entrada" placeholder="Titulo de tu entrada" id="titulo">
                        <textarea name="texto" id="texto" placeholder="Texto de tu entrada" class="texto" id="text"></textarea>
                        <input type="text" name="img" class="input-entrada" placeholder="Dirección de tu imagen" id="img">
                        
                        <input type="text" class="input-entrada" name="code" placeholder="Inserta un codigo por si necesitas editar">
                        
                        <input type="submit" class="btn pulse hoverable" id="btn-entradas" value="Crear Entrada">
                    </form>
                    
                </div>
            </div>
        </div>
	    
	    <div class="container contenido-entrada">
	        
	        </div>
	    
    <div class="container">
      <div class="row">
      <div class="col logout s6 ">
        <a href="php/logout.php" class="btn hoverable">Logout</a>
      </div>
      </div>
    </div>
    
<!--
<footer class="footer">
    <div class="container">
        <div class="row">
            
            <div class="col s12">
                
                <h1>Hola</h1>
                
            </div>
            
        </div>
    </div>
</footer>
-->
<script src="js/parallax.js"></script>
<script src="js/entradas.js"></script>
</body>
</html>