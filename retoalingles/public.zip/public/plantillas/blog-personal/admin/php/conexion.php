<?php

$conexion = mysqli_connect("localhost", "root", "heml12346", "freelancer");

if(!$conexion){
	echo "Error en la conexion";
}

?>