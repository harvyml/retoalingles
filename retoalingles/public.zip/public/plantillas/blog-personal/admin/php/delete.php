<?php

include 'conexion.php';

$code = $_POST["code"];


$consulta = "DELETE * FROM entradas WHERE code = '$code'";

$resultado = mysqli_query($conexion, $consulta);

if(!$resultado){
	echo 'Hay algo Mal';
}

mysqli_close($conexion);

?>