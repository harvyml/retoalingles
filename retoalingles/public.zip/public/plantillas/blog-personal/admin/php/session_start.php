<?php

include 'conexion.php';
session_start();/* siempre se pone fuera del isset */

if(isset($_SESSION["user"])){
	


}else{
	echo "hay algo mal";
}

?>