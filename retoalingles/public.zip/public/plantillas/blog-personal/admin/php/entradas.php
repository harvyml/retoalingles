<?php

include 'conexion.php';

$titulo = $_POST["titulo"];
$img = $_POST["img"];
$texto = $_POST["texto"];
$code = $_POST["code"];

$consulta = "INSERT INTO entradas (titulo, texto, img, code) VALUES ('$titulo','$texto', '$img', '$code')";

$resultado = mysqli_query($conexion, $consulta);


if(!$resultado){
	echo "hay un error";
}

mysqli_close($conexion);

?>