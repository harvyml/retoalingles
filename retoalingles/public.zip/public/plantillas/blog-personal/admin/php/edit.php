<?php

include 'conexion.php';

$img = $_POST["img"];
$texto = $_POST["texto"];
$code = $_POST["code"];


$consulta = "UPDATE entradas SET texto = $texto, img = $img, fecha=$texto WHERE code = '$code'";

$resultado = mysqli_query($conexion, $consulta);

if(!$resultado){
	echo "Hay algo mal";
}

mysqli_close($conexion);


?>