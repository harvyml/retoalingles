<?php 

include 'conexion.php';

$user = $_POST["user"];
$password = $_POST["password"];


if(isset($password) && isset($user)){
    $conexion;
    
    $consulta = "SELECT * FROM admin WHERE user ='$user' AND password='$password'";
    $resultado = mysqli_query($conexion, $consulta);
    
    if(mysqli_num_rows($resultado)>0){
        
        session_start();
        $_SESSION["user"] = $_POST["user"];

        
        }
        
        ?>
        <script type="text/javascript">
            window.location="../admin.php";
        </script>
        
        <?php
    }
    
    else{
        echo "<center>Datos de Acceso Incorrectos</center>";
    }
    


?>

