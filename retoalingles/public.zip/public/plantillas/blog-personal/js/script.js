$(document).ready(function(){
	
	var arrow = $('.arrow')

	arrow.on('click', function(){
		$('.social-bar-fixed').toggleClass('social-bar-hide')
	})

})