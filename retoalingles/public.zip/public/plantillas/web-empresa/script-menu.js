$(window).on('scroll', function(){

		console.log($(window).scrollTop());

		if($(window).scrollTop() > 100){
			$('header .menu').addClass('menu-script-bg')
		} 

		else{
			$('header .menu').removeClass('menu-script-bg')	
		}
})

// *******************************************************

var altura = $(window).outerHeight(true);
var ancho = $(window).outerWidth(true);

$('.menu-navegacion').css({
	height: altura+'px'
}) 

OcultarMenu();

// ********************************************************

$('#menu-boton').on('click',function(){
	MostrarMenu()
})

$('#salir').on('click', function(){
	OcultarMenu()
})

function MostrarMenu(){
	$('.menu-navegacion').css({
		left: 0
	}) 
}
function OcultarMenu(){
	$('.menu-navegacion').css({
		left: -ancho+'px'
	}) 
}

// **********************************************************

// 1

var uno = $('#description-pets').offset().top;

$('#1').on('click', function(){
	$('body').animate({scrollTop:uno-100+'px'}, 1000)
	OcultarMenu()
})