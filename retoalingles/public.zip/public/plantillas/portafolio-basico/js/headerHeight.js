$(document).ready(function (){

	// Scroll Console
	$(window).scroll(function(){
		console.log($(window).scrollTop())
	})

	var windowHeight = $(window).height()
	var header = $('header');

	// Asignando Tamaño Total del Height al header
	header.css({
		height: windowHeight+'px',
	})

	var menu = $('.menu')
	
	menu.css({
		height: windowHeight+'px',
	})

	// Ocultar y Ver Menu
	$('#btn-hide img').on('click', function(){
		menu.toggleClass('hide')
	})
})