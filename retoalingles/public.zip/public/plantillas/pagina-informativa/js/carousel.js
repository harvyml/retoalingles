 $(document).ready(function(){

      $('.carousel.carousel-slider').carousel({fullWidth: true});

       var carousel_interval = 8000;

    $('.carousel').carousel();

    run();

    var int;

    function run(){
        int = setInterval(function(){
            $('.carousel').carousel('next');
        }, carousel_interval);
    }

});
