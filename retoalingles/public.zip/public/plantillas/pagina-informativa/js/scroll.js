


/*--------------- Boton para scroll up ----------*/
$('.up-arrow').on('click', function(){
    $('body').animate({scrollTop: 0}, 700);
    $('.up-arrow').animate({backgroundColor: 'white', color: '#90caf9'},700);
});